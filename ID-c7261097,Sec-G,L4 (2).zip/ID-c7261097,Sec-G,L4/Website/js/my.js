
$(window).scroll(function(){
  if($(this).scrollTop()> 50)
  {
    $(".arrow123").show();
  }
  else
  {
    $(".arrow123").hide();
  }
})


$(document).ready(function(){
  $(".aarambha").owlCarousel({
     navText:["<div class='btn prev'>PREV</div>","<a class='btn next'>Next</a>"],
     nav:false,
     dots:false,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:3,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
  });
  $(".rahulbhai").owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    dots:false,
    autoplay:true,
    items:6,
    autoplayTimeout:2000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:false
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
  });
});







      var slider =$("#owl-slider");
        slider.owlCarousel({
        loop:true,
        nav:false,
        dots:false,

        items:5
        
      });
        // Custom Navigation Events
      $(".next").click(function(){
        slider.trigger('next.owl.carousel');

      })
      $(".prev").click(function(){
        slider.trigger('prev.owl.carousel');
  })


    

      $(function () {
        $('.toggle-menu').click(function(){
         $('.exo-menu').toggleClass('display');
         
        });
        
       });

     